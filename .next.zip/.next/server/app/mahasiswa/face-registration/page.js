(()=>{var e={};e.id=18,e.ids=[18,884,562],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},84770:e=>{"use strict";e.exports=require("crypto")},80665:e=>{"use strict";e.exports=require("dns")},17702:e=>{"use strict";e.exports=require("events")},92048:e=>{"use strict";e.exports=require("fs")},32615:e=>{"use strict";e.exports=require("http")},32694:e=>{"use strict";e.exports=require("http2")},98216:e=>{"use strict";e.exports=require("net")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},34845:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>n.a,__next_app__:()=>m,originalPathname:()=>u,pages:()=>c,routeModule:()=>p,tree:()=>d}),a(37172),a(54881),a(35866);var r=a(23191),s=a(88716),i=a(37922),n=a.n(i),o=a(95231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);a.d(t,l);let d=["",{children:["mahasiswa",{children:["face-registration",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,37172)),"E:\\Tugas Akhir final\\prototype-leads\\src\\app\\mahasiswa\\face-registration\\page.js"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,54881)),"E:\\Tugas Akhir final\\prototype-leads\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,35866,23)),"next/dist/client/components/not-found-error"]}],c=["E:\\Tugas Akhir final\\prototype-leads\\src\\app\\mahasiswa\\face-registration\\page.js"],u="/mahasiswa/face-registration/page",m={require:a,loadChunk:()=>Promise.resolve()},p=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/mahasiswa/face-registration/page",pathname:"/mahasiswa/face-registration",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},65166:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,12994,23)),Promise.resolve().then(a.t.bind(a,96114,23)),Promise.resolve().then(a.t.bind(a,9727,23)),Promise.resolve().then(a.t.bind(a,79671,23)),Promise.resolve().then(a.t.bind(a,41868,23)),Promise.resolve().then(a.t.bind(a,84759,23))},39028:(e,t,a)=>{Promise.resolve().then(a.bind(a,29989))},53356:(e,t,a)=>{Promise.resolve().then(a.bind(a,93964))},33265:(e,t,a)=>{"use strict";a.d(t,{default:()=>s.a});var r=a(43353),s=a.n(r)},43353:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return i}});let r=a(91174);a(10326),a(17577);let s=r._(a(77028));function i(e,t){var a;let r={loading:e=>{let{error:t,isLoading:a,pastDelay:r}=e;return null}};"function"==typeof e&&(r.loader=e);let i={...r,...t};return(0,s.default)({...i,modules:null==(a=i.loadableGenerated)?void 0:a.modules})}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},933:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"BailoutToCSR",{enumerable:!0,get:function(){return s}});let r=a(94129);function s(e){let{reason:t,children:a}=e;throw new r.BailoutToCSRError(t)}},77028:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return d}});let r=a(10326),s=a(17577),i=a(933),n=a(46618);function o(e){return{default:e&&"default"in e?e.default:e}}let l={loader:()=>Promise.resolve(o(()=>null)),loading:null,ssr:!0},d=function(e){let t={...l,...e},a=(0,s.lazy)(()=>t.loader().then(o)),d=t.loading;function c(e){let o=d?(0,r.jsx)(d,{isLoading:!0,pastDelay:!0,error:null}):null,l=t.ssr?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(n.PreloadCss,{moduleIds:t.modules}),(0,r.jsx)(a,{...e})]}):(0,r.jsx)(i.BailoutToCSR,{reason:"next/dynamic",children:(0,r.jsx)(a,{...e})});return(0,r.jsx)(s.Suspense,{fallback:o,children:l})}return c.displayName="LoadableComponent",c}},46618:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"PreloadCss",{enumerable:!0,get:function(){return i}});let r=a(10326),s=a(54580);function i(e){let{moduleIds:t}=e,a=(0,s.getExpectedRequestStore)("next/dynamic css"),i=[];if(a.reactLoadableManifest&&t){let e=a.reactLoadableManifest;for(let a of t){if(!e[a])continue;let t=e[a].files.filter(e=>e.endsWith(".css"));i.push(...t)}}return 0===i.length?null:(0,r.jsx)(r.Fragment,{children:i.map(e=>(0,r.jsx)("link",{precedence:"dynamic",rel:"stylesheet",href:a.assetPrefix+"/_next/"+encodeURI(e),as:"style"},e))})}},93964:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>p});var r=a(10326),s=a(17577),i=a(35047),n=a(66562),o=a(1380),l=a(96884),d=a(70884),c=a(76),u=a(36434),m=a(28604);function p(){let[e,t]=(0,s.useState)(!1),[a,p]=(0,s.useState)(""),[f,h]=(0,s.useState)(""),x=(0,s.useRef)(null),g=(0,s.useRef)(null),b=(0,i.useRouter)(),[y,v]=(0,s.useState)({nim:""}),[j,w]=(0,s.useState)(!1),N=async()=>{if(!x.current||!y.nim)return;p("capture"),h(`📸 Mengambil 20 gambar wajah dengan pose FRONT...`);let e=new FormData;e.append("nim",y.nim);for(let t=0;t<20;t++){let a=document.createElement("canvas");a.width=160,a.height=160,a.getContext("2d").drawImage(x.current,0,0,160,160),await new Promise(r=>{a.toBlob(a=>{a&&e.append("images",a,`front_${t+1}.jpg`),r()},"image/jpeg")}),await new Promise(e=>setTimeout(e,200))}try{let a=await fetch("https://exciting-thankfully-bluegill.ngrok-free.app/register-face",{method:"POST",body:e}),r=await a.json();a.ok?(h(`✅ ${r.uploaded_count} gambar berhasil diunggah.`),t(!0)):h(`❌ Gagal upload: ${r.error}`)}catch(e){console.error("❌ Upload error:",e),h("❌ Gagal mengunggah ke server.")}finally{p("")}p("training"),h("\uD83E\uDDE0 Melatih model...");try{let e=await fetch("https://exciting-thankfully-bluegill.ngrok-free.app/train-model",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`nim=${encodeURIComponent(y.nim)}`});if(!e.ok){let t=await e.json();throw Error(t.error||"Training failed")}let t=await e.json();h(t.message||"✅ Model selesai dilatih."),g.current&&g.current.getTracks().forEach(e=>e.stop());let a=JSON.parse(localStorage.getItem("pending_register"));if(a){(0,u.v0)(m.l2),(0,c.ad)(m.l2);let e=await fetch("/api/daftar-mahasiswa",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({nim:a.nim,name:a.name,email:a.email,password:a.password})}),t=await e.json();e.ok?h("✅ Pendaftaran berhasil. Mengarahkan ke halaman login..."):h(`❌ Gagal simpan data: ${t.error}`),n.Z.set("session_mahasiswa",JSON.stringify({isLoggedIn:!0,nim:a.nim,name:a.name,email:a.email})),localStorage.removeItem("pending_register")}setTimeout(()=>{localStorage.clear(),sessionStorage.clear(),Object.keys(n.Z.get()).forEach(function(e){n.Z.remove(e)}),b.push("/mahasiswa/login")},3e3)}catch(e){console.error("Training error:",e),h(`❌ Gagal training: ${e.message}`)}finally{p("")}};return(0,r.jsxs)("div",{className:"min-h-screen bg-white",children:[r.jsx(o.default,{isLoggedIn:!0,userData:y,sidebarOpen:j,setSidebarOpen:w}),r.jsx(d.Z,{sidebarOpen:j,setSidebarOpen:w}),r.jsx("div",{className:"h-[40vh] bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 pt-24 flex flex-col justify-center items-center text-white",children:r.jsx("h1",{className:"text-3xl sm:text-4xl font-bold",children:"Pendaftaran Wajah"})}),r.jsx("main",{className:"flex flex-col items-center justify-center py-12 px-6 bg-white",children:(0,r.jsxs)("div",{className:"max-w-xl w-full bg-gray-50 border border-gray-200 rounded-xl shadow-md p-6",children:[r.jsx("h2",{className:"text-xl font-semibold mb-4 text-center",children:"Kamera Langsung"}),r.jsx("video",{ref:x,autoPlay:!0,playsInline:!0,className:"w-full h-[400px] object-cover bg-black rounded"}),!e&&(0,r.jsxs)("div",{className:"text-center mt-4 space-y-2",children:[(0,r.jsxs)("p",{className:"font-medium text-gray-600",children:["Pose yang diminta: ",r.jsx("strong",{children:"FRONT"})," (menghadap depan)"]}),r.jsx("button",{onClick:N,className:"bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded",children:"Ambil 20 Gambar Wajah"})]}),a?(0,r.jsxs)("div",{className:"text-center mt-4 flex flex-col items-center gap-2 text-blue-600 font-medium",children:[(0,r.jsxs)("svg",{className:"animate-spin h-5 w-5 text-blue-600",viewBox:"0 0 24 24",children:[r.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4",fill:"none"}),r.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"})]}),r.jsx("p",{children:"capture"===a?"\uD83D\uDCF8 Mengambil gambar wajah...":"\uD83E\uDDE0 Sedang melatih model..."})]}):null,f&&r.jsx("p",{className:`text-center mt-4 font-medium ${f.startsWith("❌")?"text-red-600":"text-green-600"}`,children:r.jsx("p",{className:`text-center mt-4 font-medium ${f.startsWith("❌")?"text-red-600":"text-green-600"}`,children:f})})]})}),r.jsx(l.default,{})]})}},96884:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>i});var r=a(10326),s=a(46226);function i(){return(0,r.jsxs)("footer",{className:"bg-[#212e72] py-8 mt-8 text-white",children:[(0,r.jsxs)("div",{className:"max-w-screen-xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 px-6 sm:px-12 text-sm mt-10",children:[(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-bold text-2xl mb-4",children:"Contact"}),r.jsx("p",{className:"text-[#8e99c6] mb-2",children:"Universitas Pembangunan Nasional Veteran Jakarta"}),r.jsx("p",{className:"text-[#8e99c6] mb-2",children:"Jl. RS. Fatmawati, Pondok Labu, Jakarta Selatan, DKI Jakarta. 12450."}),r.jsx("p",{className:"text-[#8e99c6] mb-2",children:"+6221-765 6971"}),r.jsx("p",{className:"text-[#8e99c6] mb-2",children:"elearning@upnvj.ac.id"})]}),(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-semibold text-2xl mb-4",children:"University"}),(0,r.jsxs)("ul",{className:"text-[#8e99c6]",children:[r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Portal UPNVJ"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"About Us"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Contact"})})]})]}),(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-semibold text-2xl mb-4",children:"Faculty"}),(0,r.jsxs)("ul",{className:"text-[#8e99c6]",children:[r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Economics and Business"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Medicine"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Engineering"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Law"})})]})]}),(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-semibold text-2xl mb-4",children:"Learning Resources"}),(0,r.jsxs)("ul",{className:"text-[#8e99c6]",children:[r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Library"})}),r.jsx("li",{className:"mb-2",children:r.jsx("a",{href:"#",className:"hover:underline",children:"Journal"})})]})]}),(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-semibold text-white text-3xl mb-4",children:"Get Mobile Moodle"}),(0,r.jsxs)("div",{className:"flex gap-6",children:[" ",(0,r.jsxs)("a",{href:"#",className:"flex items-center gap-3 text-white p-3 rounded-md",children:[r.jsx("i",{className:"fa fa-apple text-7xl"})," ",r.jsx("span",{className:"font-light",children:"App Store"})]}),(0,r.jsxs)("a",{href:"#",className:"flex items-center gap-3 text-white p-3 rounded-md",children:[r.jsx("i",{className:"fa fa-android text-7xl"})," ",r.jsx("span",{className:"font-light",children:"Google Play"})]})]})]})]}),r.jsx("div",{className:"flex justify-center mt-8",children:r.jsx(s.default,{src:"/images/logo/leads_poppins.png",alt:"LeADS Logo",width:192,height:0,className:"w-48 h-auto",loading:"lazy"})}),r.jsx("div",{className:"text-center text-xs mt-8 font-light",children:r.jsx("p",{children:"\xa9 2021 UPN Veteran Jakarta"})})]})}},66021:(e,t,a)=>{"use strict";a.d(t,{Z:()=>s});var r=a(10326);function s(){return r.jsx("div",{className:"fixed inset-0 bg-white z-50 flex items-center justify-center",children:r.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-4 border-blue-600 border-solid"})})}},29989:(e,t,a)=>{"use strict";a.d(t,{default:()=>o});var r=a(10326),s=a(35047),i=a(17577),n=a(66021);function o({children:e}){(0,s.useRouter)(),(0,s.usePathname)();let[t,a]=(0,i.useState)(!1);return(0,r.jsxs)(r.Fragment,{children:[t&&r.jsx(n.Z,{}),e]})}},70884:(e,t,a)=>{"use strict";a.d(t,{Z:()=>eb});var r,s=a(10326),i=a(17577),n=a(33265),o=a(66562),l=a(35047);let d={data:""},c=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||d,u=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,m=/\/\*[^]*?\*\/|  +/g,p=/\n+/g,f=(e,t)=>{let a="",r="",s="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+n+";":r+="f"==i[1]?f(n,i):i+"{"+f(n,"k"==i[1]?"":t)+"}":"object"==typeof n?r+=f(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=f.p?f.p(i,n):i+":"+n+";")}return a+(t&&s?t+"{"+s+"}":s)+r},h={},x=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+x(e[a]);return t}return e},g=(e,t,a,r,s)=>{let i=x(e),n=h[i]||(h[i]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(i));if(!h[n]){let t=i!==e?e:(e=>{let t,a,r=[{}];for(;t=u.exec(e.replace(m,""));)t[4]?r.shift():t[3]?(a=t[3].replace(p," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(p," ").trim();return r[0]})(e);h[n]=f(s?{["@keyframes "+n]:t}:t,a?"":"."+n)}let o=a&&h.g?h.g:null;return a&&(h.g=h[n]),((e,t,a,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=a?e+t.data:t.data+e)})(h[n],t,r,o),n},b=(e,t,a)=>e.reduce((e,r,s)=>{let i=t[s];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":f(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function y(e){let t=this||{},a=e.call?e(t.p):e;return g(a.unshift?a.raw?b(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,c(t.target),t.g,t.o,t.k)}y.bind({g:1});let v,j,w,N=y.bind({k:1});function k(e,t){let a=this||{};return function(){let r=arguments;function s(i,n){let o=Object.assign({},i),l=o.className||s.className;a.p=Object.assign({theme:j&&j()},o),a.o=/ *go\d+/.test(l),o.className=y.apply(a,r)+(l?" "+l:""),t&&(o.ref=n);let d=e;return e[0]&&(d=o.as||e,delete o.as),w&&d[0]&&w(o),v(d,o)}return t?t(s):s}}var P=e=>"function"==typeof e,S=(e,t)=>P(e)?e(t):e,E=(()=>{let e=0;return()=>(++e).toString()})(),C=(()=>{let e;return()=>e})(),O=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return O(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let s=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+s}))}}},_=[],D={toasts:[],pausedAt:void 0},M=e=>{D=O(D,e),_.forEach(e=>{e(D)})},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},$=(e={})=>{let[t,a]=(0,i.useState)(D),r=(0,i.useRef)(D);(0,i.useEffect)(()=>(r.current!==D&&a(D),_.push(a),()=>{let e=_.indexOf(a);e>-1&&_.splice(e,1)}),[]);let s=t.toasts.map(t=>{var a,r,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(a=e[t.type])?void 0:a.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||T[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...t,toasts:s}},A=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||E()}),I=e=>(t,a)=>{let r=A(t,e,a);return M({type:2,toast:r}),r.id},R=(e,t)=>I("blank")(e,t);R.error=I("error"),R.success=I("success"),R.loading=I("loading"),R.custom=I("custom"),R.dismiss=e=>{M({type:3,toastId:e})},R.remove=e=>M({type:4,toastId:e}),R.promise=(e,t,a)=>{let r=R.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?S(t.success,e):void 0;return s?R.success(s,{id:r,...a,...null==a?void 0:a.success}):R.dismiss(r),e}).catch(e=>{let s=t.error?S(t.error,e):void 0;s?R.error(s,{id:r,...a,...null==a?void 0:a.error}):R.dismiss(r)}),e};var q=(e,t)=>{M({type:1,toast:{id:e,height:t}})},F=()=>{M({type:5,time:Date.now()})},L=new Map,U=1e3,z=(e,t=U)=>{if(L.has(e))return;let a=setTimeout(()=>{L.delete(e),M({type:4,toastId:e})},t);L.set(e,a)},G=e=>{let{toasts:t,pausedAt:a}=$(e);(0,i.useEffect)(()=>{if(a)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let a=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(a<0){t.visible&&R.dismiss(t.id);return}return setTimeout(()=>R.dismiss(t.id),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,a]);let r=(0,i.useCallback)(()=>{a&&M({type:6,time:Date.now()})},[a]),s=(0,i.useCallback)((e,a)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:i}=a||{},n=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),o=n.findIndex(t=>t.id===e.id),l=n.filter((e,t)=>t<o&&e.visible).length;return n.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[t]);return(0,i.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)z(e.id,e.removeDelay);else{let t=L.get(e.id);t&&(clearTimeout(t),L.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:q,startPause:F,endPause:r,calculateOffset:s}}},B=N`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Z=N`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=N`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,V=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${B} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Z} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${J} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,W=N`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,H=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${W} 1s linear infinite;
`,K=N`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,Q=N`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Y=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${Q} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,X=k("div")`
  position: absolute;
`,ee=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,et=N`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ea=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${et} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,er=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?i.createElement(ea,null,t):t:"blank"===a?null:i.createElement(ee,null,i.createElement(H,{...r}),"loading"!==a&&i.createElement(X,null,"error"===a?i.createElement(V,{...r}):i.createElement(Y,{...r})))},es=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ei=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,en=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eo=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,el=(e,t)=>{let a=e.includes("top")?1:-1,[r,s]=C()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[es(a),ei(a)];return{animation:t?`${N(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${N(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ed=i.memo(({toast:e,position:t,style:a,children:r})=>{let s=e.height?el(e.position||t||"top-center",e.visible):{opacity:0},n=i.createElement(er,{toast:e}),o=i.createElement(eo,{...e.ariaProps},S(e.message,e));return i.createElement(en,{className:e.className,style:{...s,...a,...e.style}},"function"==typeof r?r({icon:n,message:o}):i.createElement(i.Fragment,null,n,o))});r=i.createElement,f.p=void 0,v=r,j=void 0,w=void 0;var ec=({id:e,className:t,style:a,onHeightUpdate:r,children:s})=>{let n=i.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return i.createElement("div",{ref:n,className:t,style:a},s)},eu=(e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:C()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}},em=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:s,containerStyle:n,containerClassName:o})=>{let{toasts:l,handlers:d}=G(a);return i.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:o,onMouseEnter:d.startPause,onMouseLeave:d.endPause},l.map(a=>{let n=a.position||t,o=eu(n,d.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return i.createElement(ec,{id:a.id,key:a.id,onHeightUpdate:d.updateHeight,className:a.visible?em:"",style:o},"custom"===a.type?S(a.message,a):s?s(a):i.createElement(ed,{toast:a,position:n}))}))},ef=a(66021);let eh=(0,n.default)(()=>Promise.all([a.e(622),a.e(38)]).then(a.bind(a,79038)),{loadableGenerated:{modules:["components\\Sidebar\\index.js -> ./MenuMain"]}}),ex=(0,n.default)(()=>Promise.all([a.e(622),a.e(238)]).then(a.bind(a,54238)),{loadableGenerated:{modules:["components\\Sidebar\\index.js -> ./MenuProfile"]}}),eg=(0,n.default)(()=>a.e(342).then(a.bind(a,59342)),{loadableGenerated:{modules:["components\\Sidebar\\index.js -> ./MenuFaculty"]}});function eb({sidebarOpen:e,setSidebarOpen:t}){let[a,r]=(0,i.useState)("main"),[n,d]=(0,i.useState)({nim:""}),[c,u]=(0,i.useState)(!1),m=(0,l.useRouter)(),p=(0,i.useCallback)(()=>{document.cookie.split(";").forEach(e=>{document.cookie=e.replace(/^ +/,"").replace(/=.*/,"=;expires="+new Date().toUTCString()+";path=/")}),localStorage.clear(),sessionStorage.clear(),o.Z.remove("session_mahasiswa"),R.success("Logout sukses!"),setTimeout(()=>{m.push("/mahasiswa/login")},1500)},[m]),f=(0,i.useCallback)(e=>{window.location.pathname!==e&&(m.push(e),t(!1))},[m,t]),h=(0,i.useMemo)(()=>"main"===a?"translate-x-0":"faculty"===a?"-translate-x-[320px]":"-translate-x-[640px]",[a]);return(0,s.jsxs)(s.Fragment,{children:[c&&s.jsx(ef.Z,{}),s.jsx(ep,{position:"top-center",reverseOrder:!1}),(0,s.jsxs)("div",{className:`sidebar fixed top-0 left-0 h-full w-80 bg-black text-white border-r border-gray-700 transition-transform duration-300 z-50 ${e?"translate-x-0":"-translate-x-full"}`,style:{willChange:"transform",contain:"paint"},onClick:e=>e.stopPropagation(),children:[(0,s.jsxs)("div",{className:"flex items-center justify-center text-base font-bold py-4 border-b border-gray-700 uppercase bg-gray-800 relative",children:["main"!==a&&s.jsx("button",{onClick:()=>r("main"),className:"absolute left-4 text-white",children:"←"}),"main"===a?"Menu":"faculty"===a?"Fakultas":n.nim]}),(0,s.jsxs)("div",{className:"flex flex-col h-full",children:[s.jsx("div",{className:"relative w-full flex-1 overflow-hidden",children:(0,s.jsxs)("div",{className:`flex transition-transform duration-300 ${h}`,style:{width:"960px",willChange:"transform"},children:[s.jsx(eh,{handleNavigation:f,setMode:r,userData:n}),s.jsx(eg,{handleNavigation:f}),s.jsx(ex,{handleNavigation:f,handleLogout:p,loading:c})]})}),s.jsx("div",{className:"px-6 py-4 border-t border-gray-700 flex items-center gap-2 text-xs text-gray-400",children:"✉ leads@upnvj.ac.id"})]})]})]})}},28604:(e,t,a)=>{"use strict";a.d(t,{I8:()=>l,db:()=>d,l2:()=>o,tO:()=>c});var r=a(42585),s=a(36434),i=a(76),n=a(11552);let o=(0,r.ZF)({apiKey:"AIzaSyADFeQ19nlQnlcS2FmVOA7AMNTe8VuyPOo",authDomain:"tugas-akhir-c22c5.firebaseapp.com",databaseURL:"https://tugas-akhir-c22c5-default-rtdb.firebaseio.com",projectId:"tugas-akhir-c22c5",storageBucket:"tugas-akhir-c22c5.appspot.com",messagingSenderId:"129744099038",appId:"1:129744099038:web:d27c08e18b6c30e10fd44f",measurementId:"G-MRY6L97DP4"}),l=(0,s.v0)(o),d=(0,i.ad)(o),c=(0,n.cF)(o)},54881:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>c,metadata:()=>d});var r=a(19510),s=a(94401),i=a.n(s),n=a(15422),o=a.n(n);a(5023);let l=(0,a(68570).createProxy)(String.raw`E:\Tugas Akhir final\prototype-leads\src\components\RouteTransitionWrapper.js#default`),d={title:"LEADS UPN Veteran Jakarta",description:"Sistem pembelajaran digital"};function c({children:e}){return(0,r.jsxs)("html",{lang:"id",className:`${i().variable} ${o().variable}`,children:[(0,r.jsxs)("head",{children:[r.jsx("link",{rel:"icon",href:"/images/logo/leads_poppins.png",type:"image/png"}),r.jsx("link",{rel:"stylesheet",href:"https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css"})]}),r.jsx("body",{className:"antialiased font-sans bg-gray-50 text-gray-900",children:r.jsx(l,{children:e})})]})}},37172:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>r});let r=(0,a(68570).createProxy)(String.raw`E:\Tugas Akhir final\prototype-leads\src\app\mahasiswa\face-registration\page.js#default`)},5023:()=>{},66562:(e,t,a)=>{"use strict";function r(e){for(var t=1;t<arguments.length;t++){var a=arguments[t];for(var r in a)e[r]=a[r]}return e}a.d(t,{Z:()=>s});var s=function e(t,a){function s(e,s,i){if("undefined"!=typeof document){"number"==typeof(i=r({},a,i)).expires&&(i.expires=new Date(Date.now()+864e5*i.expires)),i.expires&&(i.expires=i.expires.toUTCString()),e=encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape);var n="";for(var o in i)i[o]&&(n+="; "+o,!0!==i[o]&&(n+="="+i[o].split(";")[0]));return document.cookie=e+"="+t.write(s,e)+n}}return Object.create({set:s,get:function(e){if("undefined"!=typeof document&&(!arguments.length||e)){for(var a=document.cookie?document.cookie.split("; "):[],r={},s=0;s<a.length;s++){var i=a[s].split("="),n=i.slice(1).join("=");try{var o=decodeURIComponent(i[0]);if(r[o]=t.read(n,o),e===o)break}catch(e){}}return e?r[e]:r}},remove:function(e,t){s(e,"",r({},t,{expires:-1}))},withAttributes:function(t){return e(this.converter,r({},this.attributes,t))},withConverter:function(t){return e(r({},this.converter,t),this.attributes)}},{attributes:{value:Object.freeze(a)},converter:{value:Object.freeze(t)}})}({read:function(e){return'"'===e[0]&&(e=e.slice(1,-1)),e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent)},write:function(e){return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,decodeURIComponent)}},{path:"/"})}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[948,838,463,226,380],()=>a(34845));module.exports=r})();